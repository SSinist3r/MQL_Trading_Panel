Standard Library Patch for MetaTrader 4 (28/02/2017)
Unzip to MQL4/Include